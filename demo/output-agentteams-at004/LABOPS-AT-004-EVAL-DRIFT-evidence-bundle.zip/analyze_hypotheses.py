#!/usr/bin/env python3
"""RCA Analyst (handoff 2/6) for DEMO-EVAL-DRIFT-004 (LABOPS-AT-004-EVAL-DRIFT).

Read-only hypothesis ranking. Loads collected_evidence.json produced by
evidence-collector (handoff 1/6), builds the four required candidate hypotheses
via the labops diagnosis engine, enriches each with an explicit fact_boundary,
validates against hypothesis.schema.json, and writes hypotheses.json.

NO execution, NO action, NO conclusion beyond ranked candidates.
"""

from __future__ import annotations

import json
import sys
from pathlib import Path

TASK_ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(TASK_ROOT))

from labops.contracts import validate_document  # noqa: E402
from labops.at004 import diagnose_eval_drift  # noqa: E402

EVIDENCE = TASK_ROOT / "artifacts" / "DEMO-EVAL-DRIFT-004" / "evidence" / "collected_evidence.json"
OUTPUT = TASK_ROOT / "artifacts" / "DEMO-EVAL-DRIFT-004" / "hypotheses.json"

# fact_boundary per hypothesis_id: what the evidence does / does NOT establish.
FACT_BOUNDARY = {
    "H-AT004-PREPROCESSING-DRIFT": (
        "Evidence establishes that evaluation.preprocessing_profile is the ONLY recorded config change "
        "(E-AT004-008), that the current profile is train_augmented (seed=77, noise_std=1.35) while the "
        "historical baseline used eval_standard (E-AT004-004/005/006), and that current accuracy "
        "0.71875x3 is repeat-stable vs historical 0.978x3 (E-AT004-007). Evidence does NOT itself prove "
        "causation; it requires a controlled experiment that flips only preprocessing_profile to the "
        "historical value and re-runs 3x to confirm recovery to >=0.97."
    ),
    "H-AT004-RANDOMNESS": (
        "Evidence establishes that current evaluations are [0.71875,0.71875,0.71875] with repeat spread "
        "0.000000 and historical are [0.978...,0.978...,0.978...] with spread 0.000000 (E-AT004-007). "
        "Zero spread across three repeats under deterministic augmentation parameters is strong "
        "counter-evidence against stochastic/transient variance as the cause of the 0.26 accuracy gap."
    ),
    "H-AT004-CHECKPOINT": (
        "Evidence establishes the current checkpoint hash a8a4ca3b... EXACTLY matches the historical "
        "reference hash (E-AT004-001); recent_git_diff also records checkpoint_changed=false (E-AT004-008). "
        "These are direct counter-evidence; a checkpoint-mismatch root cause is effectively excluded by "
        "the recorded hashes unless those hashes themselves are later found unreliable."
    ),
    "H-AT004-VALIDATION-DATA": (
        "Evidence establishes the current validation_data hash fa01bcbb... EXACTLY matches the historical "
        "reference hash (E-AT004-002); recent_git_diff also records validation_data_changed=false "
        "(E-AT004-008). These are direct counter-evidence; validation-data drift is effectively excluded "
        "by the recorded hashes unless those hashes themselves are later found unreliable."
    ),
}


def main() -> int:
    bundle = json.loads(EVIDENCE.read_text(encoding="utf-8"))
    diagnosis = diagnose_eval_drift(bundle)

    for hypothesis in diagnosis["hypotheses"]:
        hypothesis["fact_boundary"] = FACT_BOUNDARY[hypothesis["hypothesis_id"]]
        validate_document(hypothesis, "hypothesis.schema.json", TASK_ROOT)

    # Enforce explicit ordering by confidence (diagnosis engine already ranks),
    # but re-assert rank as 1..N.
    ranked = sorted(diagnosis["hypotheses"], key=lambda h: (-h["confidence"], h["hypothesis_id"]))
    for index, hypothesis in enumerate(ranked, 1):
        hypothesis["rank"] = index

    record = {
        "schema_version": "1.0",
        "task_id": bundle["task_id"],
        "incident_id": bundle["incident_id"],
        "analyst": "rca-analyst",
        "hypotheses": ranked,
        "top_hypothesis_id": ranked[0]["hypothesis_id"],
        "ranking_basis": "evidence support, contradicting evidence, repeat stability, verification cost and risk",
        "read_only": True,
        "executed_actions": 0,
        "excluded_data_not_read": True,
    }
    OUTPUT.parent.mkdir(parents=True, exist_ok=True)
    OUTPUT.write_text(json.dumps(record, ensure_ascii=False, indent=2), encoding="utf-8")

    print(f"Wrote {OUTPUT}")
    print(f"hypotheses={len(ranked)} top={record['top_hypothesis_id']}")
    for hypothesis in ranked:
        print(f"  rank={hypothesis['rank']} {hypothesis['hypothesis_id']} "
              f"conf={hypothesis['confidence']:.2f} risk={hypothesis['risk_level']} "
              f"support={hypothesis['supporting_evidence']} contra={hypothesis['contradicting_evidence']}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
