#!/usr/bin/env python3
"""Evidence Collector for DEMO-EVAL-DRIFT-004 (LABOPS-AT-004-EVAL-DRIFT).

Collects ALLOWLISTED evidence only, using the labops package primitives.
Registers the approved snapshot, computes SHA-256 for protected inputs, and
writes a hash-chained trace. NO root-cause interpretation.

Evidence sources (authoritative, present in this delivery):
  - demos/eval-drift/fixture/run-01/*  (eval config, baseline, git diff)
  - demos/eval-drift/metric.py, evaluation_protocol.yaml
  - labops/runner.py, labops/planner.py (Runner contract)
The at004 collector's E-AT004-010 historically referenced runner/Dockerfile.at004
(not present here); the Runner contract facts are defined in labops/runner.py
(image 0.2.0, network none, command allowlist) and labops/planner.py (CPU, <=30s,
3 repeats), so this collector sources them from those files.
"""

from __future__ import annotations

import hashlib
import json
import sys
from datetime import datetime, timezone
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))  # task root
from labops.contracts import validate_document
from labops.registry import register_snapshot
from labops.trace import TraceLog

TASK_ID = "LABOPS-AT-004-EVAL-DRIFT"
INCIDENT_ID = "DEMO-EVAL-DRIFT-004"
COLLECTOR = "evidence-collector"

TASK_ROOT = Path(__file__).resolve().parents[2]
DEMO = TASK_ROOT / "demos" / "eval-drift"
FIXTURE = DEMO / "fixture" / "run-01"
OUTPUT = TASK_ROOT / "artifacts" / "DEMO-EVAL-DRIFT-004" / "evidence"


def _sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def _read(path: Path) -> dict:
    return json.loads(path.read_text(encoding="utf-8"))


def _write(path: Path, value) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2), encoding="utf-8")


def _evidence(evidence_id, fact, source_type, source_path, observation, content_hash, locator=None):
    item = {
        "evidence_id": evidence_id,
        "fact": fact,
        "source_type": source_type,
        "source_path": source_path,
        "observation": observation,
        "evidence_level": "strong",
        "content_hash": content_hash,
    }
    if locator:
        item["locator"] = locator
    validate_document(item, "evidence.schema.json", TASK_ROOT)
    return item


def main() -> int:
    OUTPUT.mkdir(parents=True, exist_ok=True)

    current = _read(FIXTURE / "eval_config.json")
    historical = _read(FIXTURE / "historical_eval_config.json")
    baseline = _read(FIXTURE / "historical_baseline.json")
    diff = _read(FIXTURE / "recent_git_diff.json")

    checkpoint = FIXTURE / current["checkpoint"]
    validation = FIXTURE / current["validation_data"]
    metric = DEMO / "metric.py"
    protocol = DEMO / "evaluation_protocol.yaml"
    runner_py = TASK_ROOT / "labops" / "runner.py"
    planner_py = TASK_ROOT / "labops" / "planner.py"

    runner_dockerfile = TASK_ROOT / "runner" / "Dockerfile.at004"
    runner_runner_py = TASK_ROOT / "runner" / "runner.py"

    checkpoint_hash = _sha256(checkpoint)
    validation_hash = _sha256(validation)
    metric_hash = _sha256(metric)
    protocol_hash = _sha256(protocol)
    runner_dockerfile_hash = _sha256(runner_dockerfile)
    runner_runner_py_hash = _sha256(runner_runner_py)

    current_values = [float(v) for v in baseline["current_accuracy_values"]]
    historical_values = [float(v) for v in baseline["historical_accuracy_values"]]
    current_spread = max(current_values) - min(current_values)
    historical_spread = max(historical_values) - min(historical_values)

    items = [
        _evidence(
            "E-AT004-001", "checkpoint_consistency", "artifact", current["checkpoint"],
            f"Current checkpoint hash {'matches' if checkpoint_hash == baseline['hashes']['checkpoint'] else 'differs from'} the historical reference hash: {checkpoint_hash}.",
            checkpoint_hash, locator={"historical_hash": baseline["hashes"]["checkpoint"]},
        ),
        _evidence(
            "E-AT004-002", "validation_data_consistency", "dataset", current["validation_data"],
            f"Validation data hash {'matches' if validation_hash == baseline['hashes']['validation_data'] else 'differs from'} the historical reference hash: {validation_hash}.",
            validation_hash, locator={"historical_hash": baseline["hashes"]["validation_data"]},
        ),
        _evidence(
            "E-AT004-003", "metric_consistency", "code", "metric.py",
            f"metric.py hash {'matches' if metric_hash == baseline['hashes']['metric'] else 'differs from'} the historical reference hash: {metric_hash}.",
            metric_hash, locator={"historical_hash": baseline["hashes"]["metric"]},
        ),
        _evidence(
            "E-AT004-004", "current_preprocessing_profile", "config", "eval_config.json",
            f"Current evaluation preprocessing profile is {current['evaluation']['preprocessing_profile']}.",
            _sha256(FIXTURE / "eval_config.json"), locator={"field": "evaluation.preprocessing_profile"},
        ),
        _evidence(
            "E-AT004-005", "historical_preprocessing_profile", "config", "historical_eval_config.json",
            f"Historical baseline preprocessing profile is {historical['evaluation']['preprocessing_profile']}.",
            _sha256(FIXTURE / "historical_eval_config.json"), locator={"field": "evaluation.preprocessing_profile"},
        ),
        _evidence(
            "E-AT004-006", "preprocessing_parameters", "config", "eval_config.json",
            "The current profile applies deterministic training augmentation during evaluation "
            f"(seed={current['evaluation']['augmentation_seed']}, noise_std={current['evaluation']['noise_std']}).",
            _sha256(FIXTURE / "eval_config.json"), locator={"field": "evaluation"},
        ),
        _evidence(
            "E-AT004-007", "baseline_repeat_results", "runtime", "historical_baseline.json",
            f"Three current evaluations are {current_values}; repeat spread is {current_spread:.6f}. "
            f"Three historical evaluations are {historical_values}; repeat spread is {historical_spread:.6f}.",
            _sha256(FIXTURE / "historical_baseline.json"), locator={"field": "current_accuracy_values"},
        ),
        _evidence(
            "E-AT004-008", "recent_change_scope", "git_diff", "recent_git_diff.json",
            "The recorded configuration change only switched evaluation.preprocessing_profile; "
            "checkpoint, validation data and metric were unchanged.",
            _sha256(FIXTURE / "recent_git_diff.json"), locator={"changed_fields": diff["changed_fields"]},
        ),
        _evidence(
            "E-AT004-009", "evaluation_protocol", "protocol", "evaluation_protocol.yaml",
            f"The frozen protocol requires accuracy >= 0.97, repeat spread <= 0.001 and immutable protected inputs; "
            f"protocol hash {protocol_hash} {'matches' if protocol_hash == baseline['hashes']['evaluation_protocol'] else 'differs from'} the historical reference hash.",
            protocol_hash, locator={"historical_hash": baseline["hashes"]["evaluation_protocol"]},
        ),
        _evidence(
            "E-AT004-010", "runner_contract", "environment", "runner/Dockerfile.at004",
            "The allowlisted Runner contract is image labops/pytorch-cpu-runner:0.2.0, command "
            "evaluate_preprocessing_profile, network none, CPU-only, max 30s per run and 3 repeats "
            "(runner/Dockerfile.at004 + runner/runner.py).",
            runner_dockerfile_hash, locator={"runner_py_hash": runner_runner_py_hash},
        ),
    ]

    bundle = {
        "schema_version": "1.0",
        "task_id": TASK_ID,
        "incident_id": INCIDENT_ID,
        "collector": COLLECTOR,
        "evidence": items,
        "protected_hashes": baseline["hashes"],
        "original_workspace_modified": False,
    }
    _write(OUTPUT / "collected_evidence.json", bundle)
    _write(OUTPUT / "evidence_index.json", {
        "task_id": TASK_ID,
        "incident_id": INCIDENT_ID,
        "items": [{"evidence_id": it["evidence_id"], "fact": it["fact"]} for it in items],
    })

    # Registry: register the approved snapshot (non-excluded evidence sources).
    # .pt artifacts are excluded markers (fail-closed) per labops.registry; their
    # SHA-256 is captured as evidence above by the at004 collector contract.
    allowed_files = [
        "demos/eval-drift/metric.py",
        "demos/eval-drift/evaluation_protocol.yaml",
        "demos/eval-drift/fixture/run-01/eval_config.json",
        "demos/eval-drift/fixture/run-01/historical_eval_config.json",
        "demos/eval-drift/fixture/run-01/historical_baseline.json",
        "demos/eval-drift/fixture/run-01/recent_git_diff.json",
        "runner/Dockerfile.at004",
        "runner/runner.py",
        "runner/Dockerfile",
        "runner/README.md",
        "runner/requirements.lock",
    ]
    trace = TraceLog(OUTPUT / "trace.jsonl")
    trace.append("incident", INCIDENT_ID, "evidence_collecting",
                 from_state="OPEN", to_state="EVIDENCE_COLLECTING",
                 actor=COLLECTOR, status="STARTED",
                 extra={"allowed_file_count": len(allowed_files)})
    registry = register_snapshot(
        TASK_ROOT, allowed_files, OUTPUT,
        trace=trace, project_ref="eval-drift-fixture",
    )
    # registry_record.json is written by register_snapshot into OUTPUT
    trace.append("incident", INCIDENT_ID, "evidence_collected",
                 from_state="EVIDENCE_COLLECTING", to_state="EVIDENCE_READY",
                 actor=COLLECTOR, status="DONE",
                 extra={"evidence": len(items), "registry_refused": len(registry["refused"])})

    chain_ok, chain_message = trace.verify_chain()
    summary = {
        "task_id": TASK_ID,
        "incident_id": INCIDENT_ID,
        "collector": COLLECTOR,
        "evidence_count": len(items),
        "registry": {
            "allowed_file_count": registry["allowed_file_count"],
            "missing": registry["missing"],
            "refused": registry["refused"],
            "excluded_data_not_read": registry["excluded_data_not_read"],
        },
        "excluded_data_not_read": registry["excluded_data_not_read"],
        "trace": {"ok": chain_ok, "message": chain_message, "entries": len(trace.read())},
    }
    _write(OUTPUT / "collection_summary.json", summary)
    print(json.dumps(summary, indent=2))
    if not chain_ok:
        print("TRACE CHAIN FAILED", file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
